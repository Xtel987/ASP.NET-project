﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

// THIS PAGE IS USED TO TEST FOR ERRORS ONLY------------------------------------------------------------------------------------------


public partial class Badtestingpage : System.Web.UI.Page
{
    ItemsInCart cart;
    string email;
    string invoiceID;

    protected void Page_Load(object sender, EventArgs e)
    {

        cart = (ItemsInCart)Session["Cart"];
        email = (string)Session["Email"];
        if (!IsPostBack)
            this.LoadYears();
    }

    private void LoadYears()
    {
        int year = DateTime.Now.Year;
        for (int i = 0; i < 7; i++)
        {
            ddlYear.Items.Add(year.ToString());
            year += 1;
        }
    }

    protected void btnAccept_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {



            //try
            //{
                //throw new Exception("An unknown exception occurred.");
                
                
                int quantity = this.Quantity();

                double shipping = 0;
                shipping = 5.55 + (quantity - 1) * 1.40;


                decimal subTotal = this.SubTotal();
                decimal total = subTotal + Convert.ToDecimal(shipping);
                
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString);

                con.Open();

                string insertCart = "INSERT INTO TestingInvoices (Email, TotalCost, Shipping, CreditCardName, CreditCardNumber, ExpirationMonth, ExpirationYear) VALUES (@Email, @TotalCost, @Shipping, @CreditCardName, @CreditCardNumber, @ExpirationMonth, @ExpirationYear)";

                SqlCommand command = new SqlCommand(insertCart, con);

                command.Parameters.AddWithValue("@Email", txtEmail.Text);
                command.Parameters.AddWithValue("@TotalCost", total.ToString());
                command.Parameters.AddWithValue("@Shipping", shipping.ToString());
                command.Parameters.AddWithValue("@CreditCardName", lstCardType.SelectedValue);
                command.Parameters.AddWithValue("@CreditCardNumber", txtCardNumber.Text);
                command.Parameters.AddWithValue("@ExpirationMonth", ddlMonth.SelectedValue);
                command.Parameters.AddWithValue("@ExpirationYear", ddlYear.SelectedValue);

                command.ExecuteNonQuery();

                Response.Write("Purchase was a success!");

                con.Close();

                this.GetInvoiceNumber();
                Session.Remove("Cart");
                Response.Redirect("OrderCon.aspx");
            //}
            //catch (Exception ex)
            //{
            //    Session["Exception"] = ex;
            //    Response.Redirect("~/DefaultError.aspx");

            //}

        }
    }

    private void PutInvoice()
    {

        int quantity = this.Quantity();

        double shipping = 0;
        shipping = 5.55 + (quantity - 1) * 1.40;
    }

    private int Quantity()
    {
        int quantity = 0;
        for (int i = 0; i < cart.Count; i++)
        {
            CartItem cartItem = cart[i];
            quantity += cartItem.Quantity;
        }
        return quantity;
    }

    private decimal SubTotal()
    {
        decimal subTotal = 0;
        for (int i = 0; i < cart.Count; i++)
        {
            CartItem cartItem = cart[i];
            subTotal += cartItem.Quantity * cartItem.Product.ItemPrice;
        }
        return subTotal;
    }

    private void GetInvoiceNumber()
    {
        string conString = ConfigurationManager.ConnectionStrings[
            "RegConnectionString"].ConnectionString;
        SqlConnection conReg =
            new SqlConnection(conString);
        SqlCommand invoiceNoCommand =
            new SqlCommand("Select Ident_Current('TestingInvoices') From TestingInvoices", conReg);
        conReg.Open();
        invoiceID = invoiceNoCommand.ExecuteScalar().ToString();
        conReg.Close();
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Session.Remove("Cart");
        Response.Redirect("ProductOrdering.aspx");
    }
    protected void btnContinue_Click(object sender, EventArgs e)
    {
        Response.Redirect("ProductOrdering.aspx");
    }
}