﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class UserRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.DataBind();

        if (IsPostBack)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString);
            conn.Open();
            string user = "select count(*) from Customers where UserName='" + txtUserName.Text + "'";
            SqlCommand comm = new SqlCommand(user, conn);
            int temporary = Convert.ToInt32(comm.ExecuteScalar().ToString());
 
            if (temporary == 1)
            {
                Response.Write("This user already exists");
            }
            conn.Close();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString);

            conn.Open();

            string insertUser = "insert into Customers (Email, LastName, FirstName, Address, City, State, PhoneNumber, DateOfBirth, UserName, Password) values (@Email, @LName, @FName, @Address, @City, @State, @Phone, @Birth, @UName, @Pass)";
            SqlCommand comm = new SqlCommand(insertUser, conn);
            comm.Parameters.AddWithValue("@Email", txtEmail.Text);
            comm.Parameters.AddWithValue("@LName", txtLastName.Text);
            comm.Parameters.AddWithValue("@FName", txtFirstName.Text);
            comm.Parameters.AddWithValue("@Address", txtAddress.Text);
            comm.Parameters.AddWithValue("@City", txtCity.Text);
            comm.Parameters.AddWithValue("@State", txtState.Text);
            comm.Parameters.AddWithValue("@Phone", txtPhone.Text);
            comm.Parameters.AddWithValue("@Birth", txtDateOB.Text);
            comm.Parameters.AddWithValue("@UName", txtUserName.Text);
            comm.Parameters.AddWithValue("@Pass", txtPassword.Text);
            comm.ExecuteNonQuery();
            Response.Write("Registration was a success!");

            conn.Close();
            
            Response.Redirect("~/Login.aspx");
        }
        catch(Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }        
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtDateOB.Text = "";
        txtFirstName.Text = "";
        txtLastName.Text = "";
        txtAddress.Text = "";
        txtEmail.Text = "";
        txtPhone.Text = "";
        lblMessage.Text = "";
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Login.aspx");
    }
}