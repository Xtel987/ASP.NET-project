﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class E404 : System.Web.UI.Page
{
    static string prePage = String.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {   
        if (!IsPostBack)
        {
            prePage = Request.UrlReferrer.ToString();
        }
    }
    protected void btnReturn_Click(object sender, EventArgs e)
    {
        Response.Redirect(prePage);
    }
}