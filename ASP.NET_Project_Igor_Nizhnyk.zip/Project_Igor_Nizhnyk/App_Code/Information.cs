﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// Get and Set methods for customer table 
public class Information
{
	public Information(){}

    public DateTime CurrentDate { get; set; }
    public string Message { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }
	
}