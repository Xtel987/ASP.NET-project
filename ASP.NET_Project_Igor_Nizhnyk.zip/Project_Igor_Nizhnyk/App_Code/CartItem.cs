﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// Class for a Cart Item
public class CartItem
{
    public CartItem() { }

    public CartItem(ProductTable product, int quantity)
    {
        this.Product = product;
        this.Quantity = quantity;
    }

    public ProductTable Product { get; set; }
    public int Quantity { get; set; }

    public void AddQuantity(int quantity)
    {
        this.Quantity += quantity;
    }

    public string Display()
    {
        string displayString =
            Product.Name + " (" + Quantity.ToString()
            + " at " + Product.ItemPrice.ToString("c") + " each)";

        return displayString;
    }

}