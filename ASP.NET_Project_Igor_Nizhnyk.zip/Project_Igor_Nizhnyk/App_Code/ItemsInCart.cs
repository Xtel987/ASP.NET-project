﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// A class that will have multiple methods that will add, drop, or remove items. In addition to clearing the cart.
public class ItemsInCart
{
    private List<CartItem> cartItems;

    public ItemsInCart()
    {
        cartItems = new List<CartItem>();
    }

    public int Count {
        get { return cartItems.Count; }
    }

    public CartItem this[int index]
    {
        get { return cartItems[index]; }
        set { cartItems[index] = value; }
    }

    public CartItem this[string id]
    {
        get {
            foreach (CartItem c in cartItems)
                if (c.Product.ProductID == id) return c;
            return null;
        }
    }

    public static ItemsInCart GetCart()
    {
        ItemsInCart cart = (ItemsInCart)HttpContext.Current.Session["Cart"];
        if (cart == null)
            HttpContext.Current.Session["Cart"] = new ItemsInCart();
        return (ItemsInCart)HttpContext.Current.Session["Cart"];
    }

    public void AddItem(ProductTable product, int quantity)
    {
        CartItem c = new CartItem(product, quantity);
        cartItems.Add(c);
    }

    public void RemoveAt(int index)
    {
        cartItems.RemoveAt(index);
    }

    public void Clear()
    {
        cartItems.Clear();
    }
}