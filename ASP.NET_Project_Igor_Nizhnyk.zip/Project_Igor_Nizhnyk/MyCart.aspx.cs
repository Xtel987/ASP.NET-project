﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyCart : System.Web.UI.Page
{
    private ItemsInCart cartI;

    protected void Page_Load(object sender, EventArgs e)
    {
        cartI = ItemsInCart.GetCart();
        if (!IsPostBack)
            this.DisplayCart();
    }

    private void DisplayCart()
    {
        lstCart.Items.Clear();
        CartItem item;
        for (int i = 0; i < cartI.Count; i++)
        {
            item = cartI[i];
            lstCart.Items.Add(item.Display());
        }
    }
    protected void btnEmpty_Click(object sender, EventArgs e)
    {
        if (cartI.Count > 0)
        {
            cartI.Clear();
            lstCart.Items.Clear();
        }
    }
    protected void btnRemove_Click(object sender, EventArgs e)
    {
        if (cartI.Count > 0)
        {
            if (lstCart.SelectedIndex > -1)
            {
                cartI.RemoveAt(lstCart.SelectedIndex);
                this.DisplayCart();
            }
            else
            {
                lblMessage.Text = "Select an item you would like to remove.";
            }
        }
    }
    protected void btnContinueShop_Click(object sender, EventArgs e)
    {

        Response.Redirect("ProductOrdering.aspx");
    }
    protected void btnCheckOut_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/CheckOut.aspx");
    }
}