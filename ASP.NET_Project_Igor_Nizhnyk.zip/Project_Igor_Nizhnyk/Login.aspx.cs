﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnReturn_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UserRegistration.aspx");
    }

    // This method will compare the username entered with the one in the database 
    // to ensure that the user name exists and the password is accurate.
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString);

        conn.Open();

        string user = "select count(*) from Customers where UserName='" + txtUserName.Text + "'";
        SqlCommand comm = new SqlCommand(user, conn);
        int temporary = Convert.ToInt32(comm.ExecuteScalar().ToString());
        
        conn.Close();
        
        if (temporary == 1)
        {
            conn.Open();
            string CheckPassDB = "select password from Customers where UserName='" + txtUserName.Text + "'";

            SqlCommand passCommand = new SqlCommand(CheckPassDB, conn);

            string password = passCommand.ExecuteScalar().ToString().Replace(" ","");
            
            if(password == txtPassword.Text)
            {
                Session["New"] = txtUserName.Text;
                Response.Write("This password is correct");
                Response.Redirect("~/ViewProducts.aspx");
            }
            else
            {
                Response.Write("This password is not correct");
            }
        }
        else
        {
            Response.Write("This username is not correct");
        }
    }
}