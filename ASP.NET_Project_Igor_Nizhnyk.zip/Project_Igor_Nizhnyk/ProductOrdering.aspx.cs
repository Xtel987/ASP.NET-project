﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;

public partial class ProductOrdering : System.Web.UI.Page
{
    private ProductTable selectedProduct;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            ddlProducts.DataBind();

        selectedProduct = this.GetSelectedProduct();
        lblName.Text = selectedProduct.Name;
        lblDescription.Text = selectedProduct.Description;
        lblItemPrice.Text = selectedProduct.ItemPrice.ToString("c");
    }

    private ProductTable GetSelectedProduct()
    {
        DataView productsTable = (DataView)
            SqlDataSourceProdList.Select(DataSourceSelectArguments.Empty);
        productsTable.RowFilter =
            "ProductID = '" + ddlProducts.SelectedValue + "'";
        DataRowView row = (DataRowView)productsTable[0];

        ProductTable p = new ProductTable();
        p.ProductID = row["ProductID"].ToString();
        p.Name = row["Name"].ToString();
        p.Description = row["Description"].ToString();
        p.ItemPrice = (decimal)row["ItemPrice"];
        return p;
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            ItemsInCart cart = ItemsInCart.GetCart();
            CartItem cartItem = cart[selectedProduct.ProductID];
            if (cartItem == null)
            {
                cart.AddItem(selectedProduct, Convert.ToInt32(txtQuantity.Text));
            }
            else
            {
                cartItem.AddQuantity(Convert.ToInt32(txtQuantity.Text));
            }
            Response.Redirect("MyCart.aspx");
        }
    }
}