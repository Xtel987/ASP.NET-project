﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Contact : System.Web.UI.Page
{
    // Cookies will be created to store information that was entered into the form
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie infoCookies = Request.Cookies["Info"];
        
        if (infoCookies == null)
        {
            return;
        }
            
        if (!IsPostBack)
        {
            if (infoCookies != null)
            {
                txtFirstN.Text = infoCookies["FirstName"];
                txtEmail.Text = infoCookies["Email"];
                txtLastN.Text = infoCookies["LastName"];
            }
            txtCurrentDate.Text = DateTime.Today.ToShortDateString();
            
        }

    }

    // Save the Cookies 
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
        HttpCookie infoCookies = new HttpCookie("Info");

        infoCookies["FirstName"] = txtFirstN.Text;
        infoCookies["Email"] = txtEmail.Text;
        infoCookies["LastName"] = txtLastN.Text;

        infoCookies.Expires = DateTime.Now.AddMonths(3);
        Response.Cookies.Add(infoCookies);
    }

    // Clear the text boxes 
    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtCurrentDate.Text = DateTime.Today.ToShortDateString();
        txtFirstN.Text = "";
        txtLastN.Text = "";
        txtMessage.Text = "";
        txtEmail.Text = "";
        txtPhoneN.Text = "";
        lblMessage.Text = "";

    }
}